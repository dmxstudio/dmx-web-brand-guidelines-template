# Meridian Design System — Tailwind package

Design tokens + dark-mode role tokens + foundations for the **Meridian** brand
system (Dirección B · Swiss systematic, cobalt `#2348E0`), packaged for
**Tailwind CSS**. Drop it into any Tailwind project.

> Generated from the live brand book → https://dmxstudio.github.io/dmx-web-brand-guidelines-template/

---

## What's inside

| File | Purpose |
|---|---|
| `tailwind-preset.js` | Tailwind preset — colors, type scale, radii, shadow, breakpoints. **Required.** |
| `meridian.tokens.css` | CSS variables (`:root`) + the `[data-theme="dark"]` swap. **Required** (runtime tokens + dark mode). |
| `meridian.foundations.css` | Font‑fallback faces (anti‑CLS), `overflow-x` backstop, `.table-scroll`, `.allow-shrink`. Recommended. |
| `theme-init.js` | No‑FOUC dark‑mode bootstrap (3‑state: system / light / dark) + `setTheme()` helper. For dark mode. |
| `tokens.w3c.json` | Same tokens in **W3C Design Tokens** format (Style Dictionary / Tokens Studio / Figma). Optional source of truth. |

---

## Install

Copy the folder into your project (e.g. `src/meridian/`), or install from a local path:

```bash
npm install ./meridian-design-system
```

### 1 · Wire the Tailwind preset

```js
// tailwind.config.js
module.exports = {
  presets: [require('./src/meridian/tailwind-preset.js')],
  content: ['./src/**/*.{html,js,jsx,ts,tsx,vue}'],
};
```

### 2 · Import the CSS (once, in your entry stylesheet)

```css
/* main.css — order matters */
@import './meridian/meridian.tokens.css';        /* tokens + dark-mode vars   */
@tailwind base;
@import './meridian/meridian.foundations.css';   /* fallbacks + .table-scroll */
@tailwind components;
@tailwind utilities;
```

### 3 · Enable dark mode (no flash)

Load the bootstrap **before** your CSS, in `<head>`:

```html
<script src="/src/meridian/theme-init.js"></script>
```

Toggle from anywhere:

```js
setTheme('dark');    // pin dark
setTheme('light');   // pin light
setTheme('system');  // follow the OS
```

### 4 · Load the brand fonts

```html
<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600&family=Space+Grotesk:wght@500;700&family=Space+Mono:wght@400;700&display=swap" rel="stylesheet">
```

---

## Using the tokens (Tailwind classes)

### Color — two layers

**Semantic role colors auto‑theme** (light ↔ dark) — use these for UI:

```html
<div class="bg-surface text-fg border border-line">
  <h3 class="text-accent-ink">Title</h3>
  <p class="text-fg-soft">Body…</p>
</div>
```
`bg-bg` · `bg-surface` · `bg-surface-raised` · `text-fg` · `text-fg-soft` · `text-fg-mut`
· `border-line` · `border-line-strong` · `bg-accent` · `text-accent-ink`
*(role colors are CSS‑var backed → no `/opacity` modifier).*

**Static palette** — full Tailwind features incl. opacity:

```html
<span class="bg-brand text-white">CTA</span>
<span class="bg-brand-50 text-brand-700">tag</span>
<span class="text-neutral-400">muted</span>
<span class="text-success">ok</span>  <span class="text-danger">error</span>
```
`brand` (+ `brand-50…900`, `brand-ink`) · `ink` · `mist` · `neutral-0…900` · `success` · `warning` · `danger`

### Manual dark variants (for static colors)

Role colors theme on their own; for static colors use `dark:` (driven by `[data-theme="dark"]`):

```html
<div class="bg-white dark:bg-ink text-ink dark:text-neutral-50">…</div>
```

### Typography

```html
<h1 class="font-display text-display">Hero</h1>
<h2 class="font-display text-h2">Section</h2>
<p  class="font-sans text-body">Body copy…</p>
<code class="font-mono text-sm">code</code>
```
Sizes: `text-display` · `text-h1` · `text-h2` · `text-h3` · `text-h4` · `text-body` · `text-sm` · `text-xs`
(each ships with its line‑height). Families: `font-display` (Space Grotesk) · `font-sans` (Inter) · `font-mono` (Space Mono).

### Radii · shadow · widths

`rounded-sm` 6px · `rounded-md` 10px · `rounded-lg` 16px · `shadow-card` (themed) · `max-w-read` (760px) · `max-w-site` (1200px).

### Spacing — 8pt scale

The Meridian 8pt scale **already maps to Tailwind's default spacing** (no override). Reference:

| Token | px | Tailwind class |
|---|---|---|
| s1 | 4 | `p-1` |
| s2 | 8 | `p-2` |
| s3 | 12 | `p-3` |
| s4 | 16 | `p-4` |
| s5 | 24 | `p-6` |
| s6 | 32 | `p-8` |
| s7 | 48 | `p-12` |
| s8 | 64 | `p-16` |
| s9 | 96 | `p-24` |

### Breakpoints — mobile‑first (`min-width`)

`sm` 640 · `md` 768 · `lg` 1024 · `xl` 1280 · `nav` 1000.

```html
<!-- 1 col → 2 at tablet → 3 at desktop -->
<div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">…</div>

<!-- nav: hamburger below 1000, full nav at/above -->
<nav class="hidden nav:flex">…</nav>
<button class="nav:hidden">☰</button>
```

---

## Responsive helpers (from the brand book)

- **Wide tables** never break the page — wrap them:
  ```html
  <div class="table-scroll"><table>…</table></div>
  ```
- **Grids that overflow on phones** — add `allow-shrink` to the container (lets children shrink below content width):
  ```html
  <div class="grid grid-cols-3 allow-shrink">…</div>
  ```
- `html { overflow-x: clip }` (in `foundations.css`) is a sticky‑safe backstop against any residual horizontal scroll.

---

## Dark mode — how it works

Both layers read the same source, `<html data-theme="…">`:

1. **Role tokens** (`--bg`, `--surface`, `--text`, `--accent`…) are re‑mapped under
   `:root[data-theme="dark"]` in `meridian.tokens.css`, so `bg-surface`/`text-fg`
   re‑theme automatically — no `dark:` needed.
2. **Literal brand demos do NOT invert** (swatches, palette, logo‑on‑background,
   charts) — those should use hardcoded hex, not role tokens.
3. Accent lightens on dark (`#2348E0` → `#4F6FEE`) for contrast.

---

## License

**CC BY‑NC 4.0** — free to use with attribution to DMX Studio; no commercial
use/resale without permission. Commercial license: designomexico@gmail.com.

© 2026 DMX Studio · v0.1.0

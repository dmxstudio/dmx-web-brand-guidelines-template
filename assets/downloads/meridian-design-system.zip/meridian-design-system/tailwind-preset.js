/**
 * Meridian Design System — Tailwind preset
 * Dirección B · Swiss systematic.  Brand: Cobalt #2348E0.
 *
 * Usage (tailwind.config.js):
 *   module.exports = {
 *     presets: [require('./meridian/tailwind-preset.js')],
 *     content: ['./src/**\/*.{html,js,jsx,ts,tsx,vue}'],
 *   }
 *
 * Pair with:
 *   - meridian.tokens.css      (CSS variables + dark-mode role tokens)  — required
 *   - meridian.foundations.css (font fallbacks + .table-scroll)         — recommended
 *   - theme-init.js            (no-FOUC dark-mode bootstrap)            — for dark mode
 * See README.md.
 */
module.exports = {
  // Dark mode is driven by the [data-theme="dark"] attribute set by theme-init.js
  // (same source the CSS-var role tokens swap on). Enables `dark:` variants too.
  darkMode: ['selector', '[data-theme="dark"]'],
  theme: {
    extend: {
      colors: {
        /* ---- Static palette (theme-independent; full Tailwind features incl. /opacity) ---- */
        brand: {
          DEFAULT: '#2348E0', ink: '#162E93',
          50: '#EEF2FE', 100: '#D6E0FD', 200: '#ADC0FB', 300: '#7E99F6', 400: '#4F6FEE',
          500: '#2348E0', 600: '#1B39B8', 700: '#162E93', 800: '#142772', 900: '#0E1B4D',
        },
        ink: '#0E1116',
        mist: '#EEF1F5',
        neutral: {
          0: '#FFFFFF', 50: '#F7F9FC', 100: '#EEF1F5', 200: '#E0E5EC', 300: '#CBD2DC',
          400: '#9AA3B2', 500: '#6B7280', 600: '#4B5563', 700: '#353B45', 800: '#1E232B', 900: '#0E1116',
        },
        success: '#1A8F5E', warning: '#C77A11', danger: '#D03A3A',

        /* ---- Semantic role tokens → CSS vars, so they AUTO-THEME (light/dark). ----
           Utilities: bg-bg, bg-surface, text-fg, text-fg-soft, border-line, text-accent-ink …
           Note: var()-based colors do NOT support the /opacity modifier. */
        bg: 'var(--bg)',
        'bg-soft': 'var(--bg-soft)',
        'bg-muted': 'var(--bg-muted)',
        surface: 'var(--surface)',
        'surface-raised': 'var(--surface-raised)',
        fg: 'var(--text)',
        'fg-soft': 'var(--text-soft)',
        'fg-mut': 'var(--text-mut)',
        line: 'var(--line)',
        'line-strong': 'var(--line-strong)',
        accent: 'var(--accent)',
        'accent-ink': 'var(--accent-ink)',
      },

      fontFamily: {
        display: ['Space Grotesk', 'Space Grotesk Fallback', 'system-ui', 'sans-serif'],
        sans: ['Inter', 'Inter Fallback', 'system-ui', 'sans-serif'],
        mono: ['Space Mono', 'Space Mono Fallback', 'ui-monospace', 'monospace'],
      },

      /* Type scale — usage: text-display, text-h1 … text-body. (sm/xs match Tailwind defaults.) */
      fontSize: {
        display: ['clamp(2.6rem, 1.5rem + 3.4vw, 4rem)', { lineHeight: '1.1', letterSpacing: '-0.02em' }],
        h1: ['clamp(2rem, 1.4rem + 2vw, 2.85rem)', { lineHeight: '1.1', letterSpacing: '-0.01em' }],
        h2: ['1.75rem', { lineHeight: '1.3' }],
        h3: ['1.3rem', { lineHeight: '1.3' }],
        h4: ['1.075rem', { lineHeight: '1.3' }],
        body: ['1.0625rem', { lineHeight: '1.65' }],
        sm: ['0.875rem', { lineHeight: '1.5' }],
        xs: ['0.75rem', { lineHeight: '1.4' }],
      },

      lineHeight: { tight: '1.1', snug: '1.3', body: '1.65' },

      /* Radii — note these REPLACE Tailwind's rounded-sm/md/lg with the Meridian scale. */
      borderRadius: { sm: '6px', md: '10px', lg: '16px' },

      boxShadow: {
        // Themes via the --shadow CSS var (lighter in light, deeper in dark).
        card: 'var(--shadow)',
      },

      maxWidth: {
        read: '760px',   // comfortable measure for body copy
        site: '1200px',  // page container
      },

      /* Mobile-first breakpoints (min-width). The 8pt spacing scale already matches
         Tailwind's default spacing — see README for the token→class map. */
      screens: {
        sm: '640px',   // phone → tablet
        md: '768px',   // tablet portrait
        lg: '1024px',  // desktop
        xl: '1280px',
        nav: '1000px', // nav drawer threshold: hamburger below, full nav at/above
      },
    },
  },
};

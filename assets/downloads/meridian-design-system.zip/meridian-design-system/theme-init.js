/* Meridian — no-FOUC theme bootstrap.
 *
 * Inline this in <head> BEFORE any stylesheet (or load as a blocking <script>),
 * so the correct theme is painted on the first frame (no flash).
 *
 *   <script src="meridian/theme-init.js"></script>   // blocking, in <head>
 *   — or paste the IIFE inline for zero extra request —
 *
 * 3-state model: user choice (localStorage) overrides the OS preference.
 *   setTheme('dark') | setTheme('light') | setTheme('system')   // helpers below
 */
(function () {
  try {
    var KEY = 'meridian-theme';
    var saved = localStorage.getItem(KEY); // 'light' | 'dark' | null(system)
    var t = saved || (matchMedia('(prefers-color-scheme:dark)').matches ? 'dark' : 'light');
    document.documentElement.setAttribute('data-theme', t);
  } catch (e) {}
})();

/* Optional runtime helpers (safe to delete if you wire your own toggle). */
if (typeof window !== 'undefined') {
  window.setTheme = function (mode) {
    var KEY = 'meridian-theme';
    if (mode === 'system') {
      localStorage.removeItem(KEY);
      mode = matchMedia('(prefers-color-scheme:dark)').matches ? 'dark' : 'light';
    } else {
      localStorage.setItem(KEY, mode);
    }
    document.documentElement.setAttribute('data-theme', mode);
  };
  // Follow OS changes only while the user hasn't pinned a choice.
  try {
    matchMedia('(prefers-color-scheme:dark)').addEventListener('change', function (e) {
      if (!localStorage.getItem('meridian-theme')) {
        document.documentElement.setAttribute('data-theme', e.matches ? 'dark' : 'light');
      }
    });
  } catch (e) {}
}
